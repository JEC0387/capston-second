# AI 기반 옷 추천 쇼핑몰 앱 (캡스톤디자인)

체형 분석 · 가상 옷장 · 날씨 코디 · 쇼핑 추천을 제공하는 안드로이드 앱과 백엔드 서버입니다.

| 폴더 | 내용 | 여는 프로그램 |
|---|---|---|
| `fashion_app/` | 안드로이드 앱 (Kotlin, Jetpack Compose) | Android Studio |
| `backend/` | 서버 (Python, FastAPI, YOLOv8) + Supabase DB 연동 | VS Code / 터미널 |

```
안드로이드 앱 ──HTTPS·JSON──> FastAPI 서버 ──> Supabase PostgreSQL (사용자·옷장·하트·측정 기록·취향)
                                         ├──> YOLOv8 (옷 사진 탐지)
                                         └──> OpenWeatherMap (날씨)
```

## 처음 받은 팀원이 할 일

**1. 서버 설정** — 자세한 내용은 [`backend/README.md`](backend/README.md)
1. `backend/.env.example`을 복사해 `backend/.env`로 저장
2. 팀장에게 받은 Supabase 주소(`DATABASE_URL`)와 날씨 키(`OWM_API_KEY`) 붙여넣기
3. 실행
   ```
   cd backend
   pip install -r requirements.txt
   python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
   ```

**2. 앱 설정** — 자세한 내용은 [`fashion_app/BACKEND_CONNECTION.md`](fashion_app/BACKEND_CONNECTION.md)
1. Android Studio에서 `fashion_app` 폴더 열기 (경로에 한글이 없어야 함)
2. `fashion_app/local.properties`에 `OWM_API_KEY=날씨키` 한 줄 추가
3. Run ▶

## 비밀 정보 규칙
- `.env`, `local.properties`는 GitHub에 올리지 않습니다 (`.gitignore`로 막혀 있음)
- DB 주소·API 키는 단톡이 아니라 개인 메시지로 전달합니다

## 협업 규칙
- `main`에 직접 올리지 않고, 기능별 브랜치 → Pull Request → 확인 후 병합
- 작업 전 항상 Pull로 최신 상태 받기
