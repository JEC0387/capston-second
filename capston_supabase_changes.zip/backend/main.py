"""
FashionProject 백엔드 (FastAPI + SQLAlchemy)

앱 화면 ↔ 엔드포인트 매핑
─────────────────────────────────────────────
HomeScreen           → GET  /api/home
WeatherViewModel     → GET  /api/weather             (실시간 날씨 + 조언)
WeatherOutfitScreen  → GET  /api/outfits/weather
WardrobeScreen       → GET  /api/wardrobe            [DB]
                       GET  /api/wardrobe/favorites  [DB]
                       POST /api/wardrobe            [DB]
                       POST /api/wardrobe/{id}/favorite [DB]
                       DELETE /api/wardrobe/{id}     [DB]
AddClothingScreen    → POST /api/object-detection    (YOLOv8 자동 태깅)
BodyAnalysisScreen   → POST /api/body-analysis        (전신 사진 업로드)
                       GET·POST /api/body-measurements [DB] 측정 기록
StylePreferenceScreen→ GET  /api/style-preference     [DB]
                       POST /api/style-preference/rate [DB]
VirtualFittingScreen → GET  /api/virtual-fitting/items [DB]
StyleSuggestionScreen→ GET  /api/style-suggestions
StyleAnalysisScreen  → GET  /api/style-analysis
ShopScreen           → GET  /api/products             [DB]
                       POST /api/products/{id}/like   [DB] 쇼핑 하트
                       GET  /api/products/likes       [DB]
ProductDetailScreen  → GET  /api/products/{id}        [DB]
MyPageScreen         → GET  /api/profile              [DB]
OnboardingScreen     → GET  /api/styles
                       POST /api/profile/styles       [DB]
(사이즈 추천 준비)    → GET  /api/size-charts          [DB]
─────────────────────────────────────────────
[DB] 표시: Supabase PostgreSQL 데이터베이스에 저장·조회 (backend/.env 의 DATABASE_URL)
그 외 화면 문구·추천 콘텐츠는 data.py 고정 데이터 사용

실행:  python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
문서:  http://localhost:8000/docs  (Swagger 자동 생성)
"""
import io
import shutil
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

import cv2
from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from PIL import Image
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

import data
import detection
import weather
from database import db_label, get_db
from models import BodyMeasurement, Clothing, Product, ProductLike, SizeChart, StyleRating, User
from schemas import (
    AddClothingRequest, BodyAnalysisResult, BodyMeasurementCreate, BodyMeasurementOut,
    ClothingItem, HomeResponse, LikedProductsResponse, ObjectDetectionResponse,
    ProductDetail, ProductLikeResponse, Profile, RatePreferenceRequest, ShopResponse,
    SizeChartRow, StyleAnalysisResponse, StylePreferenceResponse, StyleSuggestionResponse,
    UpdateStylesRequest, VirtualFittingResponse, WardrobeResponse, WeatherNowResponse,
    WeatherOutfitResponse,
)
from seed import DEMO_EMAIL, init_db


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()  # 표 생성 + 최초 데이터 넣기 (이미 있으면 건너뜀)
    print(f"[DB] 연결 대상: {db_label()}")
    yield


app = FastAPI(
    title="FashionProject API",
    description="AI 기반 개인 맞춤 패션 추천 서비스 백엔드",
    version="2.0.0",
    lifespan=lifespan,
)

# 앱(에뮬레이터/실기기)에서 접근할 수 있도록 CORS 전체 허용 (개발용)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 업로드된 사진 저장 폴더 (정적 서빙)
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


# ──────────────────────────────────────────────
# 현재 사용자
# ──────────────────────────────────────────────

def current_user(db: Session = Depends(get_db)) -> User:
    """
    지금 요청한 사용자.
    로그인 기능 전까지는 데모 사용자 1명을 반환한다.
    로그인을 붙이면 이 함수만 '토큰 확인 → 해당 사용자 반환'으로 바꾸면 된다.
    """
    user = db.scalar(select(User).where(User.email == DEMO_EMAIL))
    if user is None:
        raise HTTPException(500, "데모 사용자가 없습니다. 서버를 다시 시작해 주세요.")
    return user


# ──────────────────────────────────────────────
# DB 행 → 앱 응답 형식 변환
# ──────────────────────────────────────────────

def clothing_out(c: Clothing) -> dict:
    return {
        "id": c.id,
        "name": c.name,
        "category": c.category,
        "color": c.color,
        "imageUrl": c.image_url,
        "isFavorite": c.favorited_at is not None,
    }


def product_out(p: Product) -> dict:
    return {
        "id": p.id,
        "name": p.name,
        "brand": p.brand,
        "price": p.price,
        "originalPrice": p.original_price,
        "rating": p.rating,
        "reviewCount": p.review_count,
        "bgColor": p.bg_color,
        "badge": p.badge,
        "imageUrl": p.image_url,
        "productUrl": p.product_url,
    }


def measurement_out(m: BodyMeasurement) -> dict:
    return {
        "id": m.id,
        "bodyType": m.body_type,
        "confidence": m.confidence,
        "shoulderCm": m.shoulder_cm,
        "waistCm": m.waist_cm,
        "hipCm": m.hip_cm,
        "legCm": m.leg_cm,
        "shoulderHipRatio": m.shoulder_hip_ratio,
        "waistHipRatio": m.waist_hip_ratio,
        "legHeightRatio": m.leg_height_ratio,
        "measuredAt": m.measured_at.isoformat() if m.measured_at else "",
    }


def latest_body_type(db: Session, user: User) -> str | None:
    """가장 최근 측정 기록의 체형, 없으면 사용자 정보의 체형"""
    last = db.scalar(
        select(BodyMeasurement)
        .where(BodyMeasurement.user_id == user.id)
        .order_by(BodyMeasurement.measured_at.desc(), BodyMeasurement.id.desc())
        .limit(1)
    )
    return last.body_type if last else user.body_type


# ──────────────────────────────────────────────
# 홈
# ──────────────────────────────────────────────

@app.get("/api/home", response_model=HomeResponse, tags=["홈"])
def get_home():
    """홈 화면에 필요한 데이터 일괄 조회 (날씨 + 오늘의 코디 + 인기 상품)"""
    return {
        "greeting": "안녕하세요",
        "weather": data.WEATHER,
        "todayOutfits": data.TODAY_OUTFITS,
        "popularItems": data.POPULAR_ITEMS,
    }


# ──────────────────────────────────────────────
# 날씨 코디
# ──────────────────────────────────────────────

@app.get("/api/outfits/weather", response_model=WeatherOutfitResponse, tags=["코디 추천"])
def get_weather_outfits():
    """오늘 날씨 기반 AI 추천 코디 3종"""
    return {"weather": data.WEATHER, "outfits": data.WEATHER_OUTFITS}


# ──────────────────────────────────────────────
# 옷장  [DB: clothes]
# ──────────────────────────────────────────────

def _wardrobe_query(user: User):
    # 하트 누른 옷이 먼저(누른 순서대로), 나머지는 등록 순서대로 — 앱 정렬과 동일
    return (
        select(Clothing)
        .where(Clothing.user_id == user.id)
        .order_by(Clothing.favorited_at.is_(None), Clothing.favorited_at, Clothing.id)
    )


def _get_own_clothing(db: Session, user: User, item_id: int) -> Clothing:
    item = db.get(Clothing, item_id)
    if item is None or item.user_id != user.id:
        raise HTTPException(404, "해당 의류를 찾을 수 없습니다")
    return item


@app.get("/api/wardrobe", response_model=WardrobeResponse, tags=["옷장"])
def get_wardrobe(category: str = "전체", db: Session = Depends(get_db), user: User = Depends(current_user)):
    """내 옷장 조회. ?category=상의 처럼 카테고리 필터 가능"""
    query = _wardrobe_query(user)
    if category != "전체":
        query = query.where(Clothing.category == category)
    items = db.scalars(query).all()
    total = db.scalar(select(func.count()).select_from(Clothing).where(Clothing.user_id == user.id))
    return {
        "totalCount": total,
        "categories": data.WARDROBE_CATEGORIES,
        "items": [clothing_out(c) for c in items],
    }


@app.post("/api/wardrobe", response_model=ClothingItem, status_code=201, tags=["옷장"])
def add_clothing(req: AddClothingRequest, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """옷장에 의류 추가"""
    item = Clothing(
        user_id=user.id,
        name=req.name,
        category=req.category,
        color=req.color,
        color_name=req.colorName,
        image_url=req.imageUrl,
        ai_tagged=req.aiTagged,
    )
    db.add(item)
    db.flush()  # id 발급
    if not item.image_url:
        item.image_url = f"https://loremflickr.com/300/380/clothing?lock={item.id + 100}"
    db.commit()
    return clothing_out(item)


@app.post("/api/wardrobe/{item_id}/favorite", response_model=ClothingItem, tags=["옷장"])
def toggle_favorite(item_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """옷장 아이템 즐겨찾기(하트) 토글. 누른 시각을 저장해 상단 정렬에 사용"""
    item = _get_own_clothing(db, user, item_id)
    item.favorited_at = None if item.favorited_at else datetime.now()
    db.commit()
    return clothing_out(item)


@app.delete("/api/wardrobe/{item_id}", status_code=204, tags=["옷장"])
def delete_clothing(item_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """옷장에서 의류 삭제"""
    item = _get_own_clothing(db, user, item_id)
    db.delete(item)
    db.commit()


@app.get("/api/wardrobe/favorites", response_model=WardrobeResponse, tags=["옷장"])
def get_favorites(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """즐겨찾기(하트)한 의류만 조회 (누른 순서대로)"""
    favs = db.scalars(_wardrobe_query(user).where(Clothing.favorited_at.is_not(None))).all()
    return {
        "totalCount": len(favs),
        "categories": data.WARDROBE_CATEGORIES,
        "items": [clothing_out(c) for c in favs],
    }


# ──────────────────────────────────────────────
# AI 체형 분석
# ──────────────────────────────────────────────

@app.post("/api/body-analysis", response_model=BodyAnalysisResult, tags=["AI 분석"])
async def analyze_body(photo: UploadFile = File(...)):
    """
    전신 사진 업로드 → AI 체형 분석 결과 반환.

    현재 체형 분석은 앱 안(ML Kit·MediaPipe)에서 수행하므로 이 API는 고정 결과를 반환.
    앱에서 측정한 결과 저장은 POST /api/body-measurements 를 사용.
    """
    if photo.content_type not in ("image/jpeg", "image/png", "image/webp"):
        raise HTTPException(400, "jpg/png/webp 이미지만 업로드할 수 있습니다")

    ext = Path(photo.filename or "photo.jpg").suffix or ".jpg"
    saved_path = UPLOAD_DIR / f"{uuid.uuid4().hex}{ext}"
    with saved_path.open("wb") as f:
        shutil.copyfileobj(photo.file, f)

    return data.BODY_ANALYSIS_RESULT


@app.post("/api/body-measurements", response_model=BodyMeasurementOut, status_code=201, tags=["AI 분석"])
def save_body_measurement(req: BodyMeasurementCreate, db: Session = Depends(get_db),
                          user: User = Depends(current_user)):
    """체형 측정 결과 저장 (cm 값·비율). 사진은 저장하지 않고 숫자만 저장한다."""
    m = BodyMeasurement(
        user_id=user.id,
        body_type=req.bodyType,
        confidence=req.confidence,
        shoulder_cm=req.shoulderCm,
        waist_cm=req.waistCm,
        hip_cm=req.hipCm,
        leg_cm=req.legCm,
        shoulder_hip_ratio=req.shoulderHipRatio,
        waist_hip_ratio=req.waistHipRatio,
        leg_height_ratio=req.legHeightRatio,
        measured_at=datetime.now(),
    )
    db.add(m)
    user.body_type = req.bodyType
    db.commit()
    return measurement_out(m)


@app.get("/api/body-measurements", response_model=list[BodyMeasurementOut], tags=["AI 분석"])
def list_body_measurements(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """체형 측정 기록 목록 (오래된 순) — 변화 그래프용"""
    rows = db.scalars(
        select(BodyMeasurement)
        .where(BodyMeasurement.user_id == user.id)
        .order_by(BodyMeasurement.measured_at, BodyMeasurement.id)
    ).all()
    return [measurement_out(m) for m in rows]


@app.delete("/api/body-measurements", status_code=204, tags=["AI 분석"])
def delete_body_measurements(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """내 체형 측정 기록 전체 삭제 (개인정보 보호: 사용자가 직접 지울 수 있게)"""
    for m in db.scalars(select(BodyMeasurement).where(BodyMeasurement.user_id == user.id)).all():
        db.delete(m)
    db.commit()


@app.post("/api/object-detection", response_model=ObjectDetectionResponse, tags=["AI 분석"])
async def detect_objects(
    photo: UploadFile = File(...),
    conf_threshold: float = Form(0.25),
):
    """
    이미지 업로드 → YOLOv8 객체 탐지 결과 반환.

    object_detect 프로젝트(Streamlit 앱)의 탐지 기능을 API로 통합한 엔드포인트.
    - multipart/form-data, 필드명 `photo` (jpg/png/webp/bmp)
    - `conf_threshold` 폼 필드로 신뢰도 임계값 조절 가능 (기본 0.25, 0.1~0.9)
    - 응답: 객체 목록 + 라벨별 개수 통계 + 바운딩 박스가 그려진 결과 이미지 URL

    활용 예: 옷장에 의류 사진 등록 시 의류/액세서리 자동 인식,
    전신 사진에서 인물(person) 검출 후 체형 분석 파이프라인 연결 등.
    """
    if photo.content_type not in ("image/jpeg", "image/png", "image/webp", "image/bmp"):
        raise HTTPException(400, "jpg/png/webp/bmp 이미지만 업로드할 수 있습니다")
    if not 0.1 <= conf_threshold <= 0.9:
        raise HTTPException(400, "conf_threshold는 0.1 ~ 0.9 사이여야 합니다")

    try:
        image = Image.open(io.BytesIO(await photo.read()))
        image.load()
    except Exception:
        raise HTTPException(400, "이미지 파일을 해석할 수 없습니다")

    detections, counts, result_img = detection.detect_objects(
        image, conf_threshold=conf_threshold
    )

    # 결과 이미지를 uploads/에 저장하고 정적 URL로 제공
    result_name = f"detect_{uuid.uuid4().hex}.jpg"
    result_path = UPLOAD_DIR / result_name
    bgr = result_img[:, :, ::-1]  # RGB → BGR (cv2.imwrite용)
    if not cv2.imwrite(str(result_path), bgr):
        raise HTTPException(500, "결과 이미지 저장에 실패했습니다")

    return {
        "totalCount": len(detections),
        "detections": detections,
        "counts": counts,
        "resultImageUrl": f"/uploads/{result_name}",
    }


@app.get("/api/style-suggestions", response_model=StyleSuggestionResponse, tags=["AI 분석"])
def get_style_suggestions(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """체형별 스타일 제안 (추천 스타일 / 피해야 할 스타일 / 추천 상품)"""
    recommended = db.scalars(select(Product).where(Product.badge == "AI추천").order_by(Product.id)).all()
    return {
        "bodyType": latest_body_type(db, user) or data.BODY_ANALYSIS_RESULT["bodyType"],
        "summary": data.BODY_ANALYSIS_RESULT["summary"],
        "recommendedStyles": data.RECOMMENDED_STYLES,
        "avoidStyles": data.AVOID_STYLES,
        "recommendedProducts": [product_out(p) for p in recommended],
    }


@app.get("/api/style-analysis", response_model=StyleAnalysisResponse, tags=["AI 분석"])
def get_style_analysis():
    """스타일 분석 결과 (도넛 차트 분포 + 키워드 + AI 코멘트)"""
    return {
        "breakdown": data.STYLE_BREAKDOWN,
        "keywords": data.STYLE_KEYWORDS,
        "aiComment": data.STYLE_AI_COMMENT,
    }


# ──────────────────────────────────────────────
# 쇼핑  [DB: products, product_likes, size_charts]
# ──────────────────────────────────────────────

@app.get("/api/products", response_model=ShopResponse, tags=["쇼핑"])
def get_products(search: str = "", db: Session = Depends(get_db)):
    """추천 쇼핑 상품 목록. ?search=니트 처럼 검색 가능"""
    query = select(Product).order_by(Product.id)
    if search:
        query = query.where(or_(Product.name.contains(search), Product.brand.contains(search)))
    return {
        "banner": "AI가 내 체형·취향을 분석해 추천한 상품이에요",
        "products": [product_out(p) for p in db.scalars(query).all()],
    }


@app.get("/api/products/likes", response_model=LikedProductsResponse, tags=["쇼핑"])
def get_liked_products(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """하트 누른 상품 id 목록 (누른 순서대로) — 쇼핑 화면 상단 정렬용"""
    ids = db.scalars(
        select(ProductLike.product_id)
        .where(ProductLike.user_id == user.id)
        .order_by(ProductLike.liked_at, ProductLike.product_id)
    ).all()
    return {"productIds": list(ids)}


@app.post("/api/products/{product_id}/like", response_model=ProductLikeResponse, tags=["쇼핑"])
def toggle_product_like(product_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """상품 하트 토글"""
    if db.get(Product, product_id) is None:
        raise HTTPException(404, "상품을 찾을 수 없습니다")
    like = db.get(ProductLike, (user.id, product_id))
    if like:
        db.delete(like)
        liked = False
    else:
        db.add(ProductLike(user_id=user.id, product_id=product_id, liked_at=datetime.now()))
        liked = True
    db.commit()
    return {"productId": product_id, "liked": liked}


@app.get("/api/products/{product_id}", response_model=ProductDetail, tags=["쇼핑"])
def get_product_detail(product_id: int, db: Session = Depends(get_db)):
    """상품 상세 (색상/사이즈 옵션, 할인율, 최저가 정보 포함)"""
    p = db.get(Product, product_id)
    if p is None:
        raise HTTPException(404, "상품을 찾을 수 없습니다")

    extra = data.PRODUCT_DETAIL_EXTRA.get(product_id, {})
    discount = None
    if p.original_price:
        discount = round((1 - p.price / p.original_price) * 100)

    return {
        **product_out(p),
        "name": extra.get("name", p.name),
        "description": p.description,
        "colors": p.colors or [],
        "sizes": p.sizes or [],
        "discountPercent": discount,
        "lowestPriceInfo": extra.get(
            "lowestPriceInfo",
            f"최저가: {p.price:,}원 · 네이버쇼핑, 무신사, 29CM 등 비교",
        ),
    }


@app.get("/api/size-charts", response_model=list[SizeChartRow], tags=["쇼핑"])
def get_size_charts(brand: str = "", category: str = "", db: Session = Depends(get_db)):
    """사이즈표 조회 (?brand=무신사 스탠다드&category=상의). 사이즈 추천 기능에서 사용"""
    query = select(SizeChart).order_by(SizeChart.brand, SizeChart.category, SizeChart.id)
    if brand:
        query = query.where(SizeChart.brand == brand)
    if category:
        query = query.where(SizeChart.category == category)
    return [
        {
            "brand": s.brand, "category": s.category, "size": s.size_label,
            "shoulderCm": s.shoulder_cm, "chestCm": s.chest_cm, "waistCm": s.waist_cm,
            "hipCm": s.hip_cm, "lengthCm": s.length_cm,
            "measureType": s.measure_type, "sourceUrl": s.source_url,
        }
        for s in db.scalars(query).all()
    ]


# ──────────────────────────────────────────────
# 프로필 / 온보딩  [DB: users]
# ──────────────────────────────────────────────

def _profile(db: Session, user: User) -> dict:
    wardrobe_count = db.scalar(select(func.count()).select_from(Clothing).where(Clothing.user_id == user.id))
    fav_clothes = db.scalar(
        select(func.count()).select_from(Clothing)
        .where(Clothing.user_id == user.id, Clothing.favorited_at.is_not(None))
    )
    fav_products = db.scalar(select(func.count()).select_from(ProductLike).where(ProductLike.user_id == user.id))
    return {
        "nickname": user.nickname,
        "email": user.email,
        "wardrobeCount": wardrobe_count,
        "outfitCount": data.PROFILE["outfitCount"],   # 코디 저장 기능 전까지 고정값
        "favoriteCount": fav_clothes + fav_products,
        "bodyType": latest_body_type(db, user),
        "preferredStyles": user.preferred_styles or [],
    }


@app.get("/api/profile", response_model=Profile, tags=["프로필"])
def get_profile(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """마이페이지 프로필 (통계 + 체형 + 선호 스타일)"""
    return _profile(db, user)


@app.get("/api/styles", response_model=list[str], tags=["프로필"])
def get_style_options():
    """온보딩 - 선택 가능한 스타일 목록"""
    return data.STYLE_OPTIONS


@app.post("/api/profile/styles", response_model=Profile, tags=["프로필"])
def update_preferred_styles(req: UpdateStylesRequest, db: Session = Depends(get_db),
                            user: User = Depends(current_user)):
    """온보딩 '시작하기' - 선호 스타일 저장"""
    invalid = [s for s in req.styles if s not in data.STYLE_OPTIONS]
    if invalid:
        raise HTTPException(400, f"유효하지 않은 스타일: {invalid}")
    user.preferred_styles = list(req.styles)
    db.commit()
    return _profile(db, user)


# ──────────────────────────────────────────────
# 실시간 날씨 (WeatherViewModel)
# ──────────────────────────────────────────────

@app.get("/api/weather", response_model=WeatherNowResponse, tags=["날씨"])
def get_weather(lat: float = weather.DEFAULT_LAT, lon: float = weather.DEFAULT_LON):
    """
    위도·경도로 실시간 날씨 조회 → 온도·습도·상태 + 옷차림 조언.

    앱 WeatherViewModel이 기기 위치(lat/lon)로 호출.
    서버 환경변수 OWM_API_KEY 가 설정돼 있으면 실제 OpenWeatherMap을 호출하고,
    없으면 기본값(맑음 22도)으로 응답한다.
    """
    w = weather.fetch_weather(lat, lon)
    advice = weather.make_advice(w["temp"], w["humidity"], w["conditionId"])
    return {**w, "advice": advice}


# ──────────────────────────────────────────────
# 스타일 취향 학습  [DB: style_ratings]
# ──────────────────────────────────────────────

def _preference_payload(db: Session, user: User) -> dict:
    rows = db.scalars(select(StyleRating).where(StyleRating.user_id == user.id)).all()
    scores = {s: 0 for s in data.STYLE_PREFERENCE_STYLES}
    for r in rows:
        if r.style in scores:
            scores[r.style] += 2 if r.liked else -1   # 앱 StylePreferenceStore와 동일 가중치
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    return {
        "scores": [{"style": s, "score": sc} for s, sc in ranked],
        "ratedCount": len(rows),
        "topStyle": ranked[0][0],
    }


@app.get("/api/style-preference", response_model=StylePreferenceResponse, tags=["AI 분석"])
def get_style_preference(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """취향 학습 현황(스타일별 점수·누적 평가 수·최상위 스타일) 조회"""
    return _preference_payload(db, user)


@app.post("/api/style-preference/rate", response_model=StylePreferenceResponse, tags=["AI 분석"])
def rate_style_preference(req: RatePreferenceRequest, db: Session = Depends(get_db),
                          user: User = Depends(current_user)):
    """코디 카드 좋아요/싫어요 평가 기록 (like=true → +2점, false → -1점)"""
    if req.style not in data.STYLE_PREFERENCE_STYLES:
        raise HTTPException(400, f"알 수 없는 스타일: {req.style}")
    db.add(StyleRating(user_id=user.id, style=req.style, liked=req.like, rated_at=datetime.now()))
    db.commit()
    return _preference_payload(db, user)


# ──────────────────────────────────────────────
# 가상 피팅  [DB: clothes]
# ──────────────────────────────────────────────

@app.get("/api/virtual-fitting/items", response_model=VirtualFittingResponse, tags=["가상 피팅"])
def get_fitting_items(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """가상 피팅에서 입어볼 후보 의류 목록 (옷장 등록 의류 + 샘플)"""
    wardrobe = [
        {"id": c.id, "name": c.name, "category": c.category, "imageUrl": c.image_url}
        for c in db.scalars(_wardrobe_query(user)).all()
    ]
    return {"items": wardrobe + data.FITTING_SAMPLES}


@app.get("/", include_in_schema=False)
def root():
    return {"service": "FashionProject API", "docs": "/docs", "db": db_label()}
