"""
DB 표(테이블) 정의 — 설계한 7개 표.

users ─┬─< clothes            (옷장)
       ├─< body_measurements  (체형 측정 기록)
       ├─< style_ratings      (취향 학습 평가 기록)
       └─< product_likes >─ products   (쇼핑 하트)
size_charts                   (브랜드별 사이즈표, 사이즈 추천용)
"""
from datetime import datetime
from typing import Optional

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base


class User(Base):
    """사용자. 로그인 기능 전까지는 데모 사용자 1명(id=1)을 사용한다."""
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)
    password_hash: Mapped[Optional[str]] = mapped_column(String(255))   # 로그인 구현 시 사용
    nickname: Mapped[str] = mapped_column(String(50))
    height_cm: Mapped[Optional[float]] = mapped_column(Float)           # cm 측정의 기준 자
    body_type: Mapped[Optional[str]] = mapped_column(String(20))        # 최근 체형 결과
    preferred_styles: Mapped[list] = mapped_column(JSON, default=list)  # 온보딩 선택 스타일
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    clothes: Mapped[list["Clothing"]] = relationship(back_populates="user", cascade="all, delete-orphan")


class Clothing(Base):
    """옷장 의류. favorited_at(하트 누른 시각)으로 '누른 순서대로 상단' 정렬을 지원."""
    __tablename__ = "clothes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(100))
    category: Mapped[str] = mapped_column(String(20))                   # 상의/하의/아우터/신발/액세서리
    color: Mapped[str] = mapped_column(String(9), default="#EDE3D5")    # hex
    color_name: Mapped[Optional[str]] = mapped_column(String(20))       # 자동 추출 색상명
    image_url: Mapped[str] = mapped_column(Text, default="")
    ai_tagged: Mapped[bool] = mapped_column(Boolean, default=False)
    favorited_at: Mapped[Optional[datetime]] = mapped_column(DateTime)  # None이면 하트 안 누름
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    user: Mapped["User"] = relationship(back_populates="clothes")


class BodyMeasurement(Base):
    """체형 측정 기록. 측정할 때마다 한 줄씩 쌓여 변화 그래프에 사용."""
    __tablename__ = "body_measurements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    body_type: Mapped[str] = mapped_column(String(20))
    confidence: Mapped[Optional[int]] = mapped_column(Integer)           # 0~100
    shoulder_cm: Mapped[Optional[float]] = mapped_column(Float)
    waist_cm: Mapped[Optional[float]] = mapped_column(Float)
    hip_cm: Mapped[Optional[float]] = mapped_column(Float)
    leg_cm: Mapped[Optional[float]] = mapped_column(Float)
    shoulder_hip_ratio: Mapped[Optional[float]] = mapped_column(Float)
    waist_hip_ratio: Mapped[Optional[float]] = mapped_column(Float)
    leg_height_ratio: Mapped[Optional[float]] = mapped_column(Float)
    measured_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class StyleRating(Base):
    """취향 학습 평가 기록. 합계가 아니라 기록을 남겨, 점수 규칙이 바뀌어도 다시 계산 가능."""
    __tablename__ = "style_ratings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    style: Mapped[str] = mapped_column(String(20))
    liked: Mapped[bool] = mapped_column(Boolean)
    rated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Product(Base):
    """쇼핑 상품. 추후 네이버 쇼핑 API로 가져온 상품도 여기에 저장(캐싱)."""
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mall_name: Mapped[Optional[str]] = mapped_column(String(50))
    brand: Mapped[str] = mapped_column(String(50))
    name: Mapped[str] = mapped_column(String(200))
    price: Mapped[int] = mapped_column(Integer)
    original_price: Mapped[Optional[int]] = mapped_column(Integer)
    rating: Mapped[float] = mapped_column(Float, default=0.0)
    review_count: Mapped[int] = mapped_column(Integer, default=0)
    bg_color: Mapped[str] = mapped_column(String(9), default="#EDE3D5")
    badge: Mapped[Optional[str]] = mapped_column(String(20))
    category: Mapped[Optional[str]] = mapped_column(String(20))
    image_url: Mapped[str] = mapped_column(Text, default="")
    product_url: Mapped[Optional[str]] = mapped_column(Text)             # 쇼핑몰 상품 페이지
    description: Mapped[str] = mapped_column(Text, default="")
    colors: Mapped[list] = mapped_column(JSON, default=list)
    sizes: Mapped[list] = mapped_column(JSON, default=list)


class ProductLike(Base):
    """쇼핑 하트. liked_at으로 누른 순서 정렬."""
    __tablename__ = "product_likes"

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), primary_key=True)
    liked_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class SizeChart(Base):
    """브랜드·카테고리별 사이즈표 (한 줄 = 사이즈 하나). 팀원이 수집한 CSV를 가져와 저장."""
    __tablename__ = "size_charts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    brand: Mapped[str] = mapped_column(String(50), index=True)
    category: Mapped[str] = mapped_column(String(20), index=True)
    size_label: Mapped[str] = mapped_column(String(10))
    shoulder_cm: Mapped[Optional[float]] = mapped_column(Float)
    chest_cm: Mapped[Optional[float]] = mapped_column(Float)
    waist_cm: Mapped[Optional[float]] = mapped_column(Float)
    hip_cm: Mapped[Optional[float]] = mapped_column(Float)
    length_cm: Mapped[Optional[float]] = mapped_column(Float)
    measure_type: Mapped[Optional[str]] = mapped_column(String(10))      # "단면" 또는 "둘레"
    source_url: Mapped[Optional[str]] = mapped_column(Text)
