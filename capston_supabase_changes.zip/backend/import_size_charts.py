"""
사이즈표 CSV → DB(size_charts 표) 가져오기.

사용법 (backend 폴더에서):
    python import_size_charts.py ../docs/data/size_charts.csv
    python import_size_charts.py ../docs/data/size_charts.csv --replace   # 기존 사이즈표 지우고 새로

CSV 첫 줄(제목)은 아래 이름을 사용 (엑셀에서 'CSV UTF-8'로 저장):
    브랜드, 카테고리, 사이즈, 어깨, 가슴, 허리, 엉덩이, 총장, 기준, 출처 링크
- 단위는 cm, 비어 있는 칸은 그대로 비워두면 됨
- 기준: "단면" 또는 "둘레"
"""
import csv
import sys

from sqlalchemy import delete

from database import SessionLocal, db_label
from models import SizeChart
from seed import init_db

# CSV 제목 → DB 열 (비슷한 이름도 허용)
COLUMN_ALIASES = {
    "brand": ["브랜드", "brand"],
    "category": ["카테고리", "category"],
    "size_label": ["사이즈", "size"],
    "shoulder_cm": ["어깨", "어깨너비", "shoulder"],
    "chest_cm": ["가슴", "가슴단면", "chest"],
    "waist_cm": ["허리", "허리단면", "waist"],
    "hip_cm": ["엉덩이", "힙", "hip"],
    "length_cm": ["총장", "length"],
    "measure_type": ["기준", "단면/둘레", "측정기준"],
    "source_url": ["출처 링크", "출처", "링크", "url"],
}
REQUIRED = ["brand", "category", "size_label"]


def _find(row: dict, field: str):
    for name in COLUMN_ALIASES[field]:
        for key in row:
            if key and key.strip().lower() == name.lower():
                value = (row[key] or "").strip()
                return value or None
    return None


def _to_float(value):
    if value is None:
        return None
    try:
        return float(value.replace("cm", "").strip())
    except ValueError:
        return None


def main(path: str, replace: bool) -> None:
    init_db()
    added, skipped = 0, 0
    with open(path, encoding="utf-8-sig", newline="") as f, SessionLocal() as db:
        if replace:
            db.execute(delete(SizeChart))
        for line_no, row in enumerate(csv.DictReader(f), start=2):
            values = {field: _find(row, field) for field in COLUMN_ALIASES}
            if any(values[r] is None for r in REQUIRED):
                print(f"  {line_no}번째 줄 건너뜀: 브랜드/카테고리/사이즈 중 빈 칸이 있음")
                skipped += 1
                continue
            for field in ["shoulder_cm", "chest_cm", "waist_cm", "hip_cm", "length_cm"]:
                values[field] = _to_float(values[field])
            db.add(SizeChart(**values))
            added += 1
        db.commit()
    print(f"[{db_label()}] 사이즈표 {added}줄 저장, {skipped}줄 건너뜀")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1], replace="--replace" in sys.argv)
