"""
DB 접속 설정 — Supabase PostgreSQL 전용.

backend/.env 파일의 DATABASE_URL 로 Supabase에 접속한다.
    DATABASE_URL=postgresql://postgres.xxxx:비밀번호@aws-0-ap-northeast-2.pooler.supabase.com:5432/postgres

팀원 모두 같은 Supabase DB를 쓰도록, 주소가 없으면 다른 DB로 대신 실행하지 않고 멈춘다.
SQLAlchemy 로 작성해서, 나중에 다른 PostgreSQL(학교 클라우드 등)로 옮겨도
DATABASE_URL 한 줄만 바꾸면 된다.
"""
import os

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

load_dotenv()  # backend/.env 읽기

DATABASE_URL = os.getenv("DATABASE_URL", "").strip()

if not DATABASE_URL:
    raise RuntimeError(
        "\n\n[DB 설정 필요] backend/.env 파일에 DATABASE_URL 이 없습니다.\n"
        "1) Supabase 프로젝트 상단 Connect → Session pooler 주소 복사\n"
        "2) backend/.env.example 을 복사해 backend/.env 로 저장\n"
        "3) DATABASE_URL= 뒤에 붙여넣고 [YOUR-PASSWORD] 를 DB 비밀번호로 교체\n"
        "자세한 방법은 backend/README.md 참고\n"
    )

# 일부 서비스가 주는 "postgres://" 형식을 SQLAlchemy 형식으로 보정
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

if not DATABASE_URL.startswith("postgresql"):
    raise RuntimeError(
        "\n\n[DB 설정 오류] DATABASE_URL 은 postgresql:// 로 시작하는 Supabase 주소여야 합니다.\n"
    )

engine = create_engine(
    DATABASE_URL,
    connect_args={"sslmode": "require"},  # Supabase는 암호화 연결 사용
    pool_pre_ping=True,                   # 오래 쉰 연결이 끊겼는지 사용 전에 확인
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    """모든 테이블 모델의 부모 클래스"""


def get_db():
    """요청마다 DB 세션을 열고, 끝나면 닫는다 (FastAPI Depends 용)."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def db_label() -> str:
    """서버 시작 로그용: 비밀번호를 가린 접속 대상 표시"""
    host = DATABASE_URL.split("@")[-1].split("/")[0]
    return f"Supabase PostgreSQL ({host})"
