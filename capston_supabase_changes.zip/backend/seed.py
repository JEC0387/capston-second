"""
서버 시작 시 실행: 표가 없으면 만들고, 비어 있으면 기존 더미 데이터(data.py)를 넣는다.
이미 데이터가 있으면 아무것도 하지 않으므로 여러 번 실행해도 안전하다.
"""
from sqlalchemy import select
from sqlalchemy.orm import Session

import data
from database import Base, SessionLocal, engine
from models import Clothing, Product, User

# 로그인 기능 전까지 사용할 데모 사용자 (이메일로 식별).
# id를 직접 지정하지 않아야 PostgreSQL의 자동 번호가 꼬이지 않는다.
DEMO_EMAIL = data.PROFILE["email"]


def init_db() -> None:
    Base.metadata.create_all(bind=engine)  # 없는 표만 새로 만듦

    with SessionLocal() as db:
        _seed_user_and_wardrobe(db)
        _seed_products(db)
        db.commit()


def _seed_user_and_wardrobe(db: Session) -> None:
    if db.scalar(select(User).where(User.email == DEMO_EMAIL)) is not None:
        return

    p = data.PROFILE
    user = User(
        email=DEMO_EMAIL,
        nickname=p["nickname"],
        body_type=p.get("bodyType"),
        preferred_styles=list(p.get("preferredStyles", [])),
    )
    db.add(user)
    db.flush()

    for item in data.WARDROBE_ITEMS:
        db.add(Clothing(
            user_id=user.id,
            name=item["name"],
            category=item["category"],
            color=item["color"],
            image_url=item["imageUrl"],
        ))


def _seed_products(db: Session) -> None:
    if db.scalar(select(Product.id).limit(1)) is not None:
        return

    default_colors = ["#EDE3D5", "#F5F2EE", "#C5C5C0", "#3A3A3A"]
    default_sizes = ["XS", "S", "M", "L", "XL"]

    for p in data.PRODUCTS:
        extra = data.PRODUCT_DETAIL_EXTRA.get(p["id"], {})
        db.add(Product(  # 순서대로 넣어 새 DB에서는 id가 1번부터 기존과 같게 매겨짐
            brand=p["brand"],
            name=p["name"],
            price=p["price"],
            original_price=p.get("originalPrice"),
            rating=p["rating"],
            review_count=p["reviewCount"],
            bg_color=p["bgColor"],
            badge=p.get("badge"),
            category=p.get("category"),
            image_url=p["imageUrl"],
            product_url=p.get("productUrl"),
            description=extra.get("description", ""),
            colors=extra.get("colors", default_colors),
            sizes=extra.get("sizes", default_sizes),
        ))


if __name__ == "__main__":
    init_db()
    print("DB 초기화 완료")
