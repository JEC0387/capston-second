# 백엔드·DB 연동 안내

앱은 FastAPI 서버를 거쳐 Supabase(PostgreSQL) DB와 데이터를 주고받습니다.
모든 연동은 **서버 우선 → 실패 시 폰 데이터** 방식이라, 서버가 꺼져 있어도 앱은 정상 동작합니다.

## 연동된 기능
| 기능 | 호출 API | DB 표 | 서버가 꺼져 있을 때 |
|---|---|---|---|
| 옷장 목록 | GET /api/wardrobe | clothes | 앱 기본 옷 목록 + 폰에 저장한 옷 |
| 옷장 하트 (누른 순서대로 상단) | POST /api/wardrobe/{id}/favorite | clothes.favorited_at | 폰에서만 정렬 |
| AI 옷 등록 | POST /api/object-detection, POST /api/wardrobe | clothes | 폰에만 저장 |
| 쇼핑 하트 | GET /api/products/likes, POST /api/products/{id}/like | product_likes | 폰에서만 정렬 |
| 체형 분석 결과 저장 | POST /api/body-measurements | body_measurements | 저장 안 함 |
| 가상 피팅 옷 목록 | GET /api/virtual-fitting/items | clothes | 폰 옷장 + 샘플 |
| 스타일 취향 학습 | GET·POST /api/style-preference | style_ratings | 폰에 점수 저장 |
| 마이페이지 프로필 | GET /api/profile | users 외 | 기본 프로필 |
| 실시간 날씨 | GET /api/weather | (DB 없음) | OpenWeatherMap 직접 호출 |

홈 화면 콘텐츠와 쇼핑 상품 이미지는 앱에 들어 있는 데이터를 그대로 사용합니다.
쇼핑 상품은 이름으로 서버 상품과 연결되므로, 상품을 바꿀 때는 앱 `ShopScreen.kt`와 서버 `backend/data.py`를 함께 수정하세요.

## 접속 주소
- 에뮬레이터: 기본값 `http://10.0.2.2:8000` 그대로 동작
- 실기기: `data/BackendApi.kt`의 `BASE_URL`을 PC 내부 IP로 변경 (예: `http://192.168.0.5:8000`)

## 날씨 API 키
키는 코드에 넣지 않습니다. `fashion_app/local.properties`(GitHub에 안 올라감)에 한 줄 추가하세요.
```
OWM_API_KEY=발급받은키
```
